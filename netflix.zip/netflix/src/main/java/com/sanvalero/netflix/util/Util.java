package com.sanvalero.netflix.util;

/**
 * Clase con métodos estáticos de utilidad
 */
public class Util {

}
